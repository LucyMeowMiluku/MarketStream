import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import streamlit as st

from config.settings import settings
from storage.db import get_engine

TICKERS = settings.tickers

PLOTLY_LAYOUT = dict(
    template="plotly_dark",
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="Space Grotesk, sans-serif", color="#e2e8f0"),
    xaxis=dict(gridcolor="#314158", zerolinecolor="#314158"),
    yaxis=dict(gridcolor="#314158", zerolinecolor="#314158"),
    margin=dict(l=0, r=0, t=40, b=0),
)


@st.cache_resource
def engine():
    return get_engine()


@st.cache_data(ttl=30)
def fetch_price_data(ticker: str, lookback: int) -> pd.DataFrame:
    query = """
        SELECT
            event_time AS window_end,
            NULLIF(input_summary->>'last_price', '')::double precision AS avg_close,
            NULLIF(factor_values->>'return_surprise', '')::double precision AS return_surprise,
            COALESCE(NULLIF(input_summary->>'trade_volume', '')::double precision, 0)
              + COALESCE(NULLIF(input_summary->>'bar_volume', '')::double precision, 0)
              AS total_volume,
            EXISTS (
                SELECT 1 FROM anomaly_alerts alert
                WHERE alert.ticker = factor_snapshots.ticker
                  AND alert.event_end = factor_snapshots.event_time
            ) AS is_anomaly
        FROM factor_snapshots
        WHERE ticker = %(ticker)s
          AND cadence = '5m'
          AND event_time > NOW() - %(lookback)s * INTERVAL '1 hour'
        ORDER BY event_time
    """
    return pd.read_sql(query, engine(), params={"ticker": ticker, "lookback": lookback})


@st.cache_data(ttl=30)
def fetch_sentiment_data(ticker: str, limit: int) -> pd.DataFrame:
    # News is persisted as MarketEvent rows; the legacy sentiment_scores table
    # is no longer written by the pipeline.
    query = """
        SELECT
            event_time AS time,
            ticker,
            payload->>'headline' AS headline,
            COALESCE(payload->>'source', feed) AS source,
            (payload->>'sentiment_score')::float AS sentiment_score,
            CASE
                WHEN (payload->>'sentiment_score')::float > 0 THEN 'positive'
                WHEN (payload->>'sentiment_score')::float < 0 THEN 'negative'
                ELSE 'neutral'
            END AS sentiment_label
        FROM market_events
        WHERE event_type = 'news' AND ticker = %(ticker)s
        ORDER BY event_time DESC
        LIMIT %(limit)s
    """
    return pd.read_sql(query, engine(), params={"ticker": ticker, "limit": limit})


@st.cache_data(ttl=30)
def fetch_anomaly_data(ticker_filter: str) -> pd.DataFrame:
    where = "WHERE ticker = %(ticker)s" if ticker_filter != "All" else ""
    params = {"ticker": ticker_filter} if ticker_filter != "All" else {}
    query = f"""
        WITH recent_alerts AS (
            SELECT detected_at, ticker, anomaly_score, reason, features, detector_scores,
                   pattern_name, direction, severity, event_start, event_end,
                   factor_evidence, trigger_event_ids, data_quality, dedupe_key
            FROM anomaly_alerts {where}
            ORDER BY detected_at DESC
            LIMIT 50
        )
        SELECT *,
            (SELECT COUNT(*) FROM anomaly_alerts {where}) as total,
            (SELECT COUNT(*) FROM anomaly_alerts {where + (" AND" if where else "WHERE")} detected_at > NOW() - INTERVAL '1 hour') as last_hour,
            (SELECT COUNT(*) FROM anomaly_alerts {where + (" AND" if where else "WHERE")} detected_at > NOW() - INTERVAL '24 hours') as last_day
        FROM recent_alerts
    """
    return pd.read_sql(query, engine(), params=params)

